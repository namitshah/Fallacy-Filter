from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.http import HttpResponse, HttpResponseBadRequest
from . import acolytes
from . import AppInfo

import gensim
from gensim.summarization import summarize
from gensim.summarization.textcleaner import split_sentences

import urllib
from urllib.parse import unquote

@csrf_exempt
def versionCheck(request):
    if request.method != 'GET':
        return HttpResponseBadRequest(400)
    try:
        return JsonResponse(AppInfo.data)
    except:
        return HttpResponseBadRequest(400)

@csrf_exempt
def docDelivery(request):
    if request.method != 'POST':
        return HttpResponseBadRequest(400)
    try:
        url = request.POST.get('url')
        url = unquote(url)

        if True:#acolytes.validateIt(url[::-1][:4], int(request.POST.get('ticket'))):
            response = acolytes.extractData(url)
            return JsonResponse(response)
    except Exception as e:
        return HttpResponseBadRequest(400)

@csrf_exempt
def articleAnalysis(request):
    print("A request was recieved...")
    if request.method != 'POST':
        return HttpResponseBadRequest(400)
    try:
        central_url = request.POST.get('central_url')
        if not acolytes.validateIt(central_url[::-1][:4], int(request.POST.get('ticket'))):
            return
        other_urls = request.POST.get('other_urls').split("<!>")
        if len(other_urls) > 8 or len(other_urls) < 3:
            return HttpResponseBadRequest(400)
        inputs = []
        target = acolytes.extractData(central_url)
        num = 0
        units = len(other_urls)
        for count in range(len(other_urls)):
            if num == 4 or (count == 5 and num != 2):
                break
            inputs.append(acolytes.extractData(other_urls[count]))
            inputs[count]['urls'] = other_urls[count]
            if inputs[count]['code'] == "-2" or other_urls[count] == central_url:
                units = units - 1
            else:
                inputs[count]['urls'] = inputs[count]['urls'] + "<!or!>" + inputs[count]['source_title']
                num = num + 1
        print(str(other_urls))
        if units < 3 or target['code'] == "-2":
            print("Exiting from here!")
            return JsonResponse({"code" : "-2"})
        response = acolytes.articleAnalysis(target, inputs)
        return JsonResponse(response)
    except Exception as e:
        print(str(e))
        return HttpResponseBadRequest(400)

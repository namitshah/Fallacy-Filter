from django.contrib import admin

# Register your models here.
from .models import ScrapedData
admin.site.register(ScrapedData)

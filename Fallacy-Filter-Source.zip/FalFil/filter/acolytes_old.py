'''
NewsFeed Filter is a lot more than just another Newsreader.
Not only does it offer its users access to millions of articles from thousands of news sources, it also enables them to compare and analyze them on the spot with other similar news articles found on the web with the help of Natural Language Processing.

Features:
<b>Access to millions of News Articles from thousands of Verified Sources:</b>
All News Articles are indexed and extracted on the go, enabling you to search for absolutely anything with the in-built search engine interface.

<b>Automated Summary Generation</b>
All News Pieces are compressed into short and cogent Summaries with the help of an Extractive Summary Generator.

<b>Analyze Articles<b>
Scrutinize and compare News Articles with other similar pieces found on the web. With an advanced NLP Algorithm at its core, the Application assigns scores to both the Target Article and its set of Statements.

<b>A clean and minimalistic interface.</b>
Expand Summaries and read Articles in their entirety. A clutter-free reading experience awaits.
'''

import math
import scipy
from scipy.spatial import distance
from html.parser import HTMLParser
import re
import gensim
from gensim.summarization import summarize
import newspaper
from newspaper import Article
import spacy
nlp = spacy.load("en_core_web_sm")
import datetime
import urllib
from urllib import request
from urllib.parse import unquote
from bs4 import BeautifulSoup
import rake_nltk
from rake_nltk import Rake, Metric
rake = Rake(max_length=2)

import tensorflow as tf
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
tf.enable_eager_execution()
import tensorflow_hub as hub
import numpy as np
encoder = hub.load("/home/namit/Documents/Python")

from . import AppInfo
from . import models

def validateIt(chars, uv_ticket):
    ticket = 0
    for char in chars:
        ticket = (ticket * 10) | ord(char)
    ticket = AppInfo.SOL % ticket
    return (ticket == uv_ticket)

def extractData(url):
    try:
        obj = models.ScrapedData.objects.get(source_link=url[:255])
    except:
        obj = None
    if obj != None and obj.status_code == 0:
        response = {}
        response['other_images'] = obj.other_images
        response['source_summary'] = obj.source_summary
        response['source_title'] = obj.source_title
        response['source_text'] = obj.source_text
        response['source_image'] = obj.source_image
        response['source_keywords'] = obj.source_keywords
        response['code'] = '0'

        obj.last_viewed = datetime.date.today()
        obj.save()
        return response
    elif obj == None or obj.status_code == -1:
        if obj is None:
            obj = models.ScrapedData(status_code=0,source_link=url[:255])
        try:
            request = urllib.request.Request(url, headers={'User-Agent' : 'Firefox/5.0'})
            html1 = urllib.request.urlopen(request, timeout=10).read()
            html1 = html1.decode('utf-8', 'ignore')
            img_html = str(html1)

            soup = BeautifulSoup(str(html1))
            if soup.figure != None:
                soup.figure.decompose()
            if soup.figcaption != None:
                soup.figcaption.decompose()
            html1 = str(soup)


            article = Article(url=url, fetch_images=True)
            article.set_html(html1)
            article.parse()
            text = article.text.split("\n\n")
            text_temp = []
            for i in range(len(text)):
                text[i] = HTMLParser().unescape(text[i])
                text[i] = re.sub("<.*>", "", text[i])
                temp_el = []
                temp_str = text[i]
                temp_count = temp_str.count(chr(34)) + temp_str.count(chr(8220)) + temp_str.count(chr(8221))
                if temp_count % 2 == 0:
                    temp_flag = False
                    for j in range(len(temp_str)):
                        if ord(temp_str[j]) in [34, 8220, 8221]:
                            temp_flag = not temp_flag
                            continue
                        if temp_str[j] == '.' and temp_flag:
                            temp_str = temp_str[:j] + chr(2727) + temp_str[j + 1:]
                    temp_el = re.sub("([^A-Z])[.][ ]*([A-Z\u201c\u201d\u0022][^.])", "\\1.\n\n\\2", temp_str)
                    temp_el = re.sub("([A-Z][a-z][.])\n\n", "\\1" + chr(2727) + " ", temp_el)
                    temp_el = temp_el.replace(chr(2727), ".")
                    temp_el = temp_el.split("\n\n")
                    text_temp = text_temp + temp_el
                else:
                    text_temp.append(text[i])
            text = text_temp

            i = len(text) - 2
            while i > -1:
                if len(text[i]) == 2:
                    text[i + 1] = text[i] + text[i + 1]
                    text[i] = ""
                i = i - 1
            avg = 0
            for i in range(len(text)):
                if len(text[i]) == 0:
                    continue
                avg = avg + len(text[i])
                count = 0
                for flag in AppInfo.flags:
                    if flag in text[i].lower():
                        count = count + 1
                    if count > 2:
                        text[i] = ""

            avg = avg // len(text)
            i = 0
            while i < len(text):
                if len(text[i]) < avg // 2:
                    text.remove(text[i])
                else:
                    i = i + 1
            response = {}

            text1 = text.copy()
            counter = 0
            for counter in range(len(text1)):
                if text1[counter].rstrip()[-1].isalnum():
                    text1[counter] = ""
                    continue
                text1[counter] = text1[counter].replace(".", "[S+P]")
            try:
                response['source_summary'] = summarize(". ".join(text1), word_count=60).replace(".", "").replace("[S+P]", ".")
            except:
                response['source_summary'] = text[0][:256]
                if len(text[0]) > 256:
                    response['source_summary'] = response['source_summary'] + "..."
            if len(response['source_summary']) == 0:
                response['source_summary'] = text[0][:256]
                if len(text[0]) > 256:
                    response['source_summary'] = response['source_summary'] + "..."

            if len(article.text) < 500 or len(article.text) > 15000 or article.title is None or len(text) < 3:
                obj.source_text = ''
                obj.status_code = -2
                try:
                    obj.save()
                except:
                    pass
                return {'code' : '-2'}

            if len(text) < 5:
                response['source_keywords'] = 'NULL'
            else:
                rake.extract_keywords_from_text(article.title)
                response['source_keywords'] = re.sub("[^A-Za-z0-9+]", "", "+".join(rake.get_ranked_phrases()[:3]).replace(" ", "+"))

                if len(response['source_keywords'].split("+")) < 5:
                    try:
                        entities = nlp(re.sub("[^A-Za-z0-9 ]", "", article.title)).ents
                        for result in entities:
                            if len(response['source_keywords'].split("+")) > 4:
                                break
                            ent_temp = result.text.replace("[^A-Za-z0-9 ]", "").replace(" ", "+")
                            if not ent_temp in response['source_keywords']:
                                if len(response['source_keywords']) > 0:
                                    response['source_keywords'] = response['source_keywords'] + "+" + ent_temp
                                else:
                                    response['source_keywords'] = ent_temp
                        if len(response['source_keywords'].split("+")) < 3:
                            if len(response['source_keywords'].split("+")) > 0 and len(article.title.split(" ")) != 0:
                                response['source_keywords'] = response['source_keywords'] + "+"
                            response['source_keywords'] = response['source_keywords'] + re.sub("[^A-Za-z0-9+]", "", "+".join(article.title.split(" ")[:4]))
                    except:
                        pass

            response['other_images'], text = extractImages(img_html, text)

            obj.other_images = response['other_images']
            response['source_title'] = HTMLParser().unescape(article.title)
            if article.top_image is None:
                obj.source_image = ""
            else:
                obj.source_image = article.top_image
            response['source_text'] = '<!?!>'.join(text);
            response['source_image'] = obj.source_image

            obj.source_text = response['source_text']
            obj.source_title = response['source_title']
            obj.source_summary = response['source_summary']
            obj.source_keywords = response['source_keywords']
            response['code'] = '0'
            obj.status_code = 0

            try:
                obj.save()
            except:
                pass
            return response
        except Exception as e:
            obj.status_code = obj.status_code - 1
            try:
                obj.save()
            except:
                pass
            return {'code' : '-2'}

    else:
        return {'code' : '-2'}


def extractImages(html1, text):
    soup = BeautifulSoup(html1, 'html.parser')
    i = 1
    anchor1 = None
    output = ""
    while i < len(text):
            try:
                anchor1 = soup.find_all(text=re.compile(text[i]))[0]
                break
            except:
                i = i + 1
    if anchor1 is not None:
        i = 0
        while i < 3 and anchor1.parent is not None:
            anchor1 = anchor1.parent
            i = i + 1
        parent = anchor1
        images = parent.find_all('img')
        if len(images) > 0:
            t_positions = []
            for t in text[:len(text)-1]:
                t_positions.append(html1.find(t[:50]))
            for img in images:
                try:
                    link_temp = html1.find(str(img['src']))
                except:
                    link_temp = -1
                index = 0
                for t in t_positions:
                    if t > link_temp and index < 3:
                        break
                    if t > link_temp:
                        if text[index - 1].find("<!*!>") == -1:
                            try:
                                temp_src = img['src']
                                if len(output) > 0:
                                    output = output + "<!>"
                                output = output + str(temp_src)
                                text[index - 1] = text[index - 1] + "<!*!>"
                            except:
                                pass
                        break
                    index = index + 1
    return output, text

def articleAnalysis(target, sources):
    targetball = target['source_text'].replace("<!*!>", "").split("<!?!>")
    targetball_enc = np.array(encoder(targetball)).tolist()
    target_art_enc = np.array(encoder([" ".join(targetball)])[0]).tolist()
    textballs = []
    textballs_enc = []
    article_sim = []

    for count in range(len(sources)):
        if sources[count]['code'] == "-2":
            textballs.append([])
            textballs_enc.append([])
            article_sim.append(0)
            continue
        textballs.append(sources[count]['source_text'].replace("<!*!>", "").split("<!?!>"))
        textballs_enc.append(np.array(encoder(textballs[count])).tolist())
        article_sim.append(1.0 - distance.cosine(target_art_enc, np.array(encoder([" ".join(textballs[count])])[0]).tolist()))
        print(str(article_sim[count]))
        print(sources[count]['urls'])
        print(sources[count]['source_title'])

    output_codes = []
    output_strings = []
    for i in range(len(targetball)):
        doc_codes = []
        doc_strings = []
        doc_differences = []
        for j in range(len(textballs)):
            temp_codes = []
            temp_differences = []
            if len(textballs[j]) == 0:
                doc_codes.append(-1)
                doc_differences.append(False)
                doc_strings.append("")
                continue
            for k in range(len(textballs[j])):
                value = 1.0 - distance.cosine(targetball_enc[i], textballs_enc[j][k])
                temp_differences.append(abs(article_sim[j] - value) > 0.40)
                temp_codes.append(value * 0.7 + article_sim[j] * 0.5)
            max_code = max(temp_codes)
            max_difference = temp_differences[temp_codes.index(max_code)]
            doc_codes.append(max_code)
            doc_differences.append(max_difference)
            doc_strings.append(textballs[j][temp_codes.index(max_code)])
        codes_copy = doc_codes.copy()
        codes_copy.sort(reverse=True)
        final_max = codes_copy[0] * 0.5 + codes_copy[1] * 0.3 + codes_copy[2] * 0.2
        final_max = math.ceil(final_max * 100)
        t_counter = 0
        for counter in range(3):
            if doc_differences[doc_codes.index(codes_copy[counter])]:
                t_counter = t_counter + 1
        if t_counter > 2:
            final_max = -1
        if final_max > -1:
            output_strings.append(doc_strings[doc_codes.index(codes_copy[0])] + "<@>" + sources[doc_codes.index(codes_copy[0])]['urls'])
            if not doc_differences[doc_codes.index(codes_copy[1])]:
                output_strings[i] = output_strings[i] + "<!#!>" + doc_strings[doc_codes.index(codes_copy[1])] + "<@>" + sources[doc_codes.index(codes_copy[1])]['urls']
        else:
            output_strings.append("")
        output_codes.append(final_max)
    final_code = 0
    minuses = 0
    for count in range(len(output_codes)):
        if output_codes[count] == -1:
            minuses = minuses + 1
            continue
        final_code = final_code + output_codes[count]
    final_code = final_code / (len(output_codes) - minuses)
    final_code = math.ceil((final_code * 0.5 + max(article_sim) * 60))

    for i in range(len(output_codes)):
        output_codes[i] = str(output_codes[i])
    response = {'code' : "0"}
    response['output_codes'] = "<!*!>".join(output_codes)
    response['output_strings'] = "<!*!>".join(output_strings)
    response['final_code'] = str(final_code)
    response['source_urls'] = ""
    for i in range(len(sources)):
        if len(textballs[i]) == 0:
            continue
        response['source_urls'] = response['source_urls'] + "<!*!>" + sources[i]['urls']
    print(str(response))
    return response

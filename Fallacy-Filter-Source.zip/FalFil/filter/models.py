from django.db import models
import datetime

class ScrapedData(models.Model):
    source_link = models.CharField(max_length=255, primary_key=True)
    source_text = models.TextField(default="")
    source_title = models.TextField(default="")
    source_summary = models.TextField(default="")
    source_image = models.TextField(default="")
    other_images = models.TextField(default="")
    source_keywords = models.CharField(max_length=255, default="")

    status_code = models.IntegerField(default=-2)
    last_viewed = models.DateField(default=datetime.date.today())

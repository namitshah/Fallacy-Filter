import tensorflow as tf
import tensorflow_hub as hub

embeddings = hub.load("/home/namit/Documents/Python")

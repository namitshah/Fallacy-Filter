import sys, gc
import math
import scipy
from scipy.spatial import distance
from html.parser import HTMLParser
import re
import gensim
from gensim.summarization import summarize
import newspaper
from newspaper import Article
import datetime
import urllib
from urllib import request
from urllib.parse import unquote
from bs4 import BeautifulSoup
import rake_nltk
from rake_nltk import Rake, Metric
rake = Rake()
import tensorflow as tf
#import tensorflow.compat.v1 as tf
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
#tf.compat.v1.disable_eager_execution()
import tensorflow_hub as hub
import numpy as np
import sentencepiece as spm

module = hub.Module("/home/namit/Documents/Python/encoder_lite/universal-sentence-encoder-lite_2")
input_placeholder = tf.sparse_placeholder(tf.int64, shape=[None, None])

with tf.Session() as sess:
  spm_path = sess.run(module(signature="spm_path"))
sp = spm.SentencePieceProcessor()
sp.Load(spm_path)
session = tf.Session()
session.run([tf.global_variables_initializer(), tf.tables_initializer()])
encodings = module(
    inputs=dict(
        values=input_placeholder.values,
        indices=input_placeholder.indices,
        dense_shape=input_placeholder.dense_shape))

from . import AppInfo
from . import models

def validateIt(chars, uv_ticket):
    ticket = 0
    for char in chars:
        ticket = (ticket * 10) | ord(char)
    ticket = AppInfo.SOL % ticket
    return (ticket == uv_ticket)

def extractData(url):
    try:
        obj = models.ScrapedData.objects.get(source_link=url[:255])
    except:
        obj = None

    if models.ScrapedData.objects.count() > 10000:
        models.ScrapedData.objects.first().delete();

    if obj != None and obj.status_code == 0:
        response = {}
        response['other_images'] = obj.other_images
        response['source_summary'] = obj.source_summary
        response['source_title'] = obj.source_title
        response['source_text'] = obj.source_text
        response['source_image'] = obj.source_image
        response['source_keywords'] = obj.source_keywords
        response['code'] = '0'

        obj.last_viewed = datetime.date.today()
        obj.save()
        return response
    elif obj == None or obj.status_code == -1:
        if obj is None:
            obj = models.ScrapedData(status_code=0,source_link=url[:255])
        try:
            request = urllib.request.Request(url, headers={'User-Agent' : 'Firefox/5.0'})
            html1 = urllib.request.urlopen(request, timeout=1.5).read()
            html1 = html1.decode('utf-8', 'ignore')
            img_html = str(html1)

            soup = BeautifulSoup(str(html1))
            if soup.figure != None:
                soup.figure.decompose()
            if soup.figcaption != None:
                soup.figcaption.decompose()
            html1 = str(soup)


            article = Article(url=url, fetch_images=True)
            article.set_html(html1)
            article.parse()
            text = article.text.split("\n\n")
            text_temp = []
            for i in range(len(text)):
                text[i] = HTMLParser().unescape(text[i])
                text[i] = re.sub("<.*>", "", text[i])
                temp_el = []
                temp_str = text[i]
                temp_count = temp_str.count(chr(34)) + temp_str.count(chr(8220)) + temp_str.count(chr(8221))
                if temp_count % 2 == 0:
                    temp_flag = False
                    for j in range(len(temp_str)):
                        if ord(temp_str[j]) in [34, 8220, 8221]:
                            temp_flag = not temp_flag
                            continue
                        if temp_str[j] == '.' and temp_flag:
                            temp_str = temp_str[:j] + chr(2727) + temp_str[j + 1:]
                    temp_el = re.sub("([^A-Z])[.][ ]*([A-Z\u201c\u201d\u0022][^.])", "\\1.\n\n\\2", temp_str)
                    temp_el = re.sub("([A-Z][a-z][.])\n\n", "\\1" + chr(2727) + " ", temp_el)
                    temp_el = temp_el.replace(chr(2727), ".")
                    temp_el = temp_el.split("\n\n")
                    text_temp = text_temp + temp_el
                else:
                    text_temp.append(text[i])
            text = text_temp

            i = len(text) - 2
            while i > -1:
                if len(text[i]) == 2:
                    text[i + 1] = text[i] + text[i + 1]
                    text[i] = ""
                i = i - 1
            avg = 0
            for i in range(len(text)):
                if len(text[i]) == 0:
                    continue
                avg = avg + len(text[i])
                count = 0
                for flag in AppInfo.flags:
                    if flag in text[i].lower():
                        count = count + 1
                    if count > 2:
                        text[i] = ""

            avg = avg // len(text)
            i = 0
            while i < len(text):
                if len(text[i]) < avg // 2:
                    text.remove(text[i])
                else:
                    i = i + 1
            response = {}

            total_len = 0
            if len(article.text) > 10000:
                for counter in range(len(text)):
                    total_len = total_len + len(text[counter])
                    if total_len > 10000:
                        text[counter - 1] = text[counter - 1] + "..."
                        text = text[:counter]
                        break

            text1 = text.copy()
            counter = 0
            for counter in range(len(text1)):
                if text1[counter].rstrip()[-1].isalnum():
                    text1[counter] = ""
                    continue
                text1[counter] = text1[counter].replace(".", "[S+P]")
            try:
                response['source_summary'] = summarize(". ".join(text1), word_count=60).replace(".", "").replace("[S+P]", ".")
            except:
                response['source_summary'] = text[0][:256]
                if len(text[0]) > 256:
                    response['source_summary'] = response['source_summary'] + "..."
            if len(response['source_summary']) == 0:
                response['source_summary'] = text[0][:256]
                if len(text[0]) > 256:
                    response['source_summary'] = response['source_summary'] + "..."

            if len(article.text) < 500 or article.title is None or len(text) < 4:
                obj.source_text = ''
                obj.status_code = -2
                try:
                    obj.save()
                except:
                    pass
                return {'code' : '-2'}

            if len(text) < 4:
                response['source_keywords'] = 'NULL'
            else:
                key_text = article.title
                rake.extract_keywords_from_text(key_text)
                phrases = rake.get_ranked_phrases()[:2]
                response['source_keywords'] = re.sub("[ ]+", "+", re.sub("[^A-Za-z0-9 ]", "", " ".join(phrases)))
            response['other_images'], text = extractImages(img_html, text)

            obj.other_images = response['other_images']
            response['source_title'] = HTMLParser().unescape(article.title)
            if article.top_image is None:
                obj.source_image = ""
            else:
                obj.source_image = article.top_image
            response['source_text'] = '<!?!>'.join(text);
            response['source_image'] = obj.source_image

            obj.source_text = response['source_text']
            obj.source_title = response['source_title']
            obj.source_summary = response['source_summary']
            obj.source_keywords = response['source_keywords']
            response['code'] = '0'
            obj.status_code = 0

            try:
                obj.save()
            except:
                pass
            return response
        except Exception as e:
            obj.status_code = obj.status_code - 1
            try:
                obj.save()
            except:
                pass
            return {'code' : '-2'}

    else:
        return {'code' : '-2'}


def extractImages(html1, text):
    soup = BeautifulSoup(html1, 'html.parser')
    i = 1
    anchor1 = None
    output = ""
    while i < len(text):
            try:
                anchor1 = soup.find_all(text=re.compile(text[i]))[0]
                break
            except:
                i = i + 1
    if anchor1 is not None:
        i = 0
        while i < 3 and anchor1.parent is not None:
            anchor1 = anchor1.parent
            i = i + 1
        parent = anchor1
        images = parent.find_all('img')
        if len(images) > 0:
            t_positions = []
            for t in text[:len(text)-1]:
                t_positions.append(html1.find(t[:50]))
            for img in images:
                try:
                    link_temp = html1.find(str(img['src']))
                except:
                    link_temp = -1
                index = 0
                for t in t_positions:
                    if t > link_temp and index < 3:
                        break
                    if t > link_temp:
                        if text[index - 1].find("<!*!>") == -1:
                            try:
                                temp_src = img['src']
                                if len(output) > 0:
                                    output = output + "<!>"
                                output = output + str(temp_src)
                                text[index - 1] = text[index - 1] + "<!*!>"
                            except:
                                pass
                        break
                    index = index + 1
    return output, text

def process_to_IDs_in_sparse_format(sp, sentences):
  ids = [sp.EncodeAsIds(x) for x in sentences]
  max_len = max(len(x) for x in ids)
  dense_shape=(len(ids), max_len)
  values=[item for sublist in ids for item in sublist]
  indices=[[row,col] for row in range(len(ids)) for col in range(len(ids[row]))]
  return (values, indices, dense_shape)

def encodeIt(array):
    values, indices, dense_shape = process_to_IDs_in_sparse_format(sp, array)

    temp_enc = session.run(
      encodings,
      feed_dict={input_placeholder.values: values,
                    input_placeholder.indices: indices,
                    input_placeholder.dense_shape: dense_shape})
    return np.array(temp_enc).tolist()

def hasBeenCopied(tlist, reslist, length):
    maxes = []
    dist_array = []
    copied = 0
    for i in range(len(tlist)):
        dist_array.append([])
        flag = True
        max = 0
        index = -1
        for j in range(len(reslist)):
            dist_array[i].append(1 - distance.cosine(tlist[i], reslist[j]))
            dist = dist_array[i][j]
            if dist >= 0.95 and flag:
                copied = copied + 1
                flag = False
            if dist > max:
                index = j
                max = dist
        maxes.append(index)
    if copied >= len(tlist) * 0.85 or copied >= len(reslist) * 0.85:
        return True
    list_copy = maxes.copy()
    list_copy.sort()
    if maxes == list_copy:
        return True

    maxes = []
    for i in range(len(reslist)):
        max = 0
        index = -1
        for j in range(len(tlist)):
            dist = dist_array[j][i]
            if dist > max:
                index = j
                max = dist
        maxes.append(index)
    list_copy = maxes.copy()
    list_copy.sort()
    if maxes == list_copy:
        return True
    return False

def articleAnalysis(target, sources):
    targetball = target['source_text'].replace("<!*!>", "").split("<!?!>")
    targetball_enc = encodeIt(targetball)
    #make changes here!
    #targetball_enc = np.array(encoder(targetball)).tolist()
    target_art_enc = encodeIt([" ".join(targetball)])[0]
    #make changes here!
    #target_art_enc = np.array(encoder([" ".join(targetball)])[0]).tolist()
    textballs = []
    textballs_enc = []
    article_sim = []
    t_range = 0
    for count in range(len(sources)):
        if sources[count]['code'] == "-2":
            textballs.append([])
            textballs_enc.append([])
            article_sim.append(-1)
            continue
        textballs.append(sources[count]['source_text'].replace("<!*!>", "").split("<!?!>"))
        textballs_enc.append(encodeIt(textballs[count]))
        article_sim.append(1.0 - distance.cosine(target_art_enc, encodeIt([" ".join(textballs[count])])[0]))
        if hasBeenCopied(targetball_enc, textballs_enc[count], len(textballs[count])):
            article_sim[count] = 0.01
            sources[count]['urls'] = sources[count]['urls'] + "\n[COPY]"
        print(str(article_sim[count]))
        print(sources[count]['urls'])
        print(sources[count]['source_title'])
        t_range = t_range + 1

    output_codes = []
    output_strings = []
    for i in range(len(targetball)):
        doc_codes = []
        doc_strings = []
        doc_differences = []
        for j in range(len(textballs)):
            temp_codes = []
            temp_differences = []
            if len(textballs[j]) == 0:
                doc_codes.append(-1)
                doc_differences.append(False)
                doc_strings.append("")
                continue
            for k in range(len(textballs[j])):
                value = 1.0 - distance.cosine(targetball_enc[i], textballs_enc[j][k])
                temp_differences.append(abs(article_sim[j] - value) > 0.35 and not article_sim[j] == 0.01)
                temp_codes.append(value * 0.7 + article_sim[j] * 0.3)
            max_code = max(temp_codes)
            max_difference = temp_differences[temp_codes.index(max_code)]
            doc_codes.append(max_code)
            doc_differences.append(max_difference)
            doc_strings.append(textballs[j][temp_codes.index(max_code)] + ("\n[COPY]" if article_sim[j] == 0.01 else ""))
        codes_copy = doc_codes.copy()
        codes_copy.sort(reverse=True)
        if t_range > 2:
            t_range = 3
        if t_range > 2:
            final_max = codes_copy[0] * 0.5 + codes_copy[1] * 0.4 + codes_copy[2] * 0.2
        else:
            final_max = codes_copy[0] * 0.6 + codes_copy[1] * 0.4
        final_max = math.ceil(final_max * 100)
        t_counter = 0
        for counter in range(t_range):
            if doc_differences[doc_codes.index(codes_copy[counter])]:
                t_counter = t_counter + 1
        if t_counter > 1:
            final_max = -1
        if final_max > -1:
            output_strings.append(doc_strings[doc_codes.index(codes_copy[0])] + "<@>" + sources[doc_codes.index(codes_copy[0])]['urls'])
            doc_codes[doc_codes.index(codes_copy[0])] = -1
            if not doc_differences[doc_codes.index(codes_copy[1])]:
                output_strings[i] = output_strings[i] + "<!**!>" + doc_strings[doc_codes.index(codes_copy[1])] + "<@>" + sources[doc_codes.index(codes_copy[1])]['urls'].split("<!or!>")[0]
        else:
            output_strings.append("NULL")
        output_codes.append(final_max)
    final_code = 0
    minuses = 0
    for count in range(len(output_codes)):
        if output_codes[count] == -1:
            minuses = minuses + 1
            continue
        final_code = final_code + output_codes[count]
    final_code = final_code / (len(output_codes) - minuses)
    article_orig = article_sim.copy()
    article_sim.sort(reverse=True)
    final_code = math.ceil((final_code * 0.6 + article_sim[0] * 20 + article_sim[1] * 20))

    for i in range(len(output_codes)):
        output_codes[i] = str(output_codes[i])
    response = {'code' : "0"}
    response['output_codes'] = "<!*!>".join(output_codes)
    response['output_strings'] = "<!*!>".join(output_strings)
    response['final_code'] = str(final_code)
    response['source_urls'] = ""
    for i in range(len(sources)):
        if len(textballs[i]) == 0:
            continue
        response['source_urls'] = response['source_urls'] + "<!*!>" + sources[i]['urls']
    response['source_urls'] = response['source_urls'][5:]

    code0 = article_orig.index(article_sim[0])
    t_reducer = 0
    i = 0
    while i <= code0:
        if article_orig[i] == -1:
            t_reducer = t_reducer - 1
        i=i+1
    code0 = code0 + t_reducer
    article_orig[article_orig.index(article_sim[0])] = -3
    code1 = article_orig.index(article_sim[1])
    t_reducer = 0
    i = 0
    while i <= code1:
        if article_orig[i] == -1:
            t_reducer = t_reducer - 1
        i=i+1
    code1 = code1 + t_reducer
    response['source_docs'] = str(code0) + ":" + str(99 if (article_sim[0] >= 1) else math.floor(article_sim[0] * 100)) + "<!*!>" + str(code1) + ":" + str(99 if (article_sim[1] >= 1) else math.floor(article_sim[1] * 100))

    print(str(response))
    return response

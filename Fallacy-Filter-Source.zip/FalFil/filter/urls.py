from django.urls import path
from . import views

urlpatterns = [
    path('versionCheck/', views.versionCheck, name='versionCheck'),
    path('docDelivery/', views.docDelivery, name='docDelivery'),
    path('articleAnalysis/', views.articleAnalysis, name='articleAnalysis'),
]

#Application Data:
data =  {
            'name' : 'Fallacy Filter',
            'Publisher' : 'Eclecticity',
            'version' : '1.0',
        }

SOL = 299792458
flags = ["app", "news", "download", "latest", "click", "headline", "channel", "also", "read", "share", "http"]
